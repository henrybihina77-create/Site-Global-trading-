/* =========================================================
   GLOBAL TRADING - SCRIPT
   4 petites fonctions, chacune dans sa partie.
   ========================================================= */

/* ===== 1. MENU TÉLÉPHONE : ouvrir / fermer ===== */
const bouton = document.getElementById("menuBouton");
const menu = document.getElementById("menu");
bouton.addEventListener("click", () => menu.classList.toggle("ouvert"));
// Referme le menu quand on clique sur un lien
menu.querySelectorAll("a").forEach(lien =>
  lien.addEventListener("click", () => menu.classList.remove("ouvert")));

/* ===== 2. OMBRE SOUS L'EN-TÊTE quand on descend dans la page ===== */
const entete = document.getElementById("entete");
window.addEventListener("scroll", () =>
  entete.classList.toggle("ombre", window.scrollY > 10));

/* ===== 3. APPARITION DES ÉLÉMENTS ET COMPTEURS ===== */
// Les éléments .apparait deviennent visibles quand ils entrent à l'écran
const observateur = new IntersectionObserver(entrees => {
  entrees.forEach(e => {
    if (e.isIntersecting) { e.target.classList.add("visible"); observateur.unobserve(e.target); }
  });
}, { threshold: 0.15 }); // 0.15 = visible à 15 % avant de s'animer
document.querySelectorAll(".apparait").forEach(el => observateur.observe(el));

// Compteurs des chiffres clés : compte de 0 jusqu'à data-cible (voir index.html, partie 4)
document.querySelectorAll("[data-cible]").forEach(el => {
  const cible = Number(el.dataset.cible);
  const pas = Math.max(1, Math.round(cible / 60)); // vitesse de comptage
  let n = 0;
  const minuteur = setInterval(() => {
    n = Math.min(n + pas, cible);
    el.textContent = n;
    if (n >= cible) clearInterval(minuteur);
  }, 25);
});

/* ===== 4. CONTACT : WHATSAPP ET E-MAIL ===== */
// MODIFIER : vos coordonnées (uniquement ici). Numéro WhatsApp : indicatif 237 + numéro, sans +, sans espace
const NUMERO_WHATSAPP = "237699238653";
const EMAIL_ENTREPRISE = "contact@global-trading.net";
const MESSAGE_ACCUEIL = "Bonjour Global Trading, je souhaite des informations sur vos services.";

// 4a. Les deux boutons "Nous contacter" (menu) et WhatsApp flottant ouvrent WhatsApp
["lienWhatsApp", "flottantWhatsApp"].forEach(id => {
  document.getElementById(id).href = "https://wa.me/" + NUMERO_WHATSAPP + "?text=" + encodeURIComponent(MESSAGE_ACCUEIL);
});

// 4b. Formulaire : le bouton cliqué (data-canal) décide du canal
let canal = "whatsapp";
document.querySelectorAll("#formulaire button").forEach(b =>
  b.addEventListener("click", () => canal = b.dataset.canal));

document.getElementById("formulaire").addEventListener("submit", e => {
  e.preventDefault(); // empêche le rechargement de la page
  const nom = document.getElementById("nom").value;
  const tel = document.getElementById("tel").value;
  const msg = document.getElementById("message").value;
  const texte = msg + "\n\nNom : " + nom + "\nTéléphone : " + tel;
  if (canal === "whatsapp") {
    window.open("https://wa.me/" + NUMERO_WHATSAPP + "?text=" + encodeURIComponent(texte), "_blank");
  } else {
    window.location.href = "mailto:" + EMAIL_ENTREPRISE + "?subject=" +
      encodeURIComponent("Demande de devis - " + nom) + "&body=" + encodeURIComponent(texte);
  }
});

/* ===== 5. ANNÉE AUTOMATIQUE dans le pied de page ===== */
document.getElementById("annee").textContent = new Date().getFullYear();

/* ===== 6. FENÊTRE D'AGRANDISSEMENT DES RÉALISATIONS ===== */
const fenetre = document.getElementById("fenetre");

// Ouvre la fenêtre avec les infos de la photo cliquée (src, data-titre, data-texte)
function ouvrirFenetre(figure) {
  const img = figure.querySelector("img");
  document.getElementById("fenetreImage").src = img.src;
  document.getElementById("fenetreImage").alt = img.alt;
  document.getElementById("fenetreTitre").textContent = figure.dataset.titre;
  document.getElementById("fenetreTexte").textContent = figure.dataset.texte;
  fenetre.hidden = false;
  document.body.style.overflow = "hidden"; // bloque le défilement de la page derrière
}
function fermerFenetre() {
  fenetre.hidden = true;
  document.body.style.overflow = "";
}
document.querySelectorAll(".galerie figure").forEach(f =>
  f.addEventListener("click", () => ouvrirFenetre(f)));
document.getElementById("fenetreFermer").addEventListener("click", fermerFenetre);
fenetre.addEventListener("click", e => { if (e.target === fenetre) fermerFenetre(); }); // clic sur le fond sombre
document.addEventListener("keydown", e => { if (e.key === "Escape") fermerFenetre(); });  // touche Échap
/* ===== AJOUT : TRADUCTION ===== */
// Appelée automatiquement par Google une fois son script chargé
function googleTranslateElementInit() {
  new google.translate.TranslateElement({
    pageLanguage: "fr",
    includedLanguages: "en,de,es",
autoDisplay: false
}, "google_translate_element");
}
const languesBouton = document.getElementById("languesBouton");
const languesListe = document.getElementById("languesListe");
const langueActuelle = document.getElementById("langueActuelle");
const NOMS_LANGUES = { fr: "Français", en: "English", de: "Deutsch", es: "Español" };
// Ouvre ou ferme la liste (true = ouvrir, false = fermer)
function basculerListe(ouvrir) {
  languesListe.classList.toggle("ouverte", ouvrir);
  languesBouton.setAttribute("aria-expanded", ouvrir);
}
languesBouton.addEventListener("click", e => {
  e.stopPropagation(); // évite que le clic ferme aussitôt la liste
  basculerListe(!languesListe.classList.contains("ouverte"));
});
document.addEventListener("click", () => basculerListe(false)); // clic ailleurs = fermeture
// Au chargement : affiche la langue déjà choisie (mémorisée par Google dans un cookie)
const memo = document.cookie.match(/googtrans=\/fr\/(\w+)/);
if (memo && NOMS_LANGUES[memo[1]]) langueActuelle.textContent = NOMS_LANGUES[memo[1]];
// Clic sur une langue de la liste
document.querySelectorAll("#languesListe [data-lang]").forEach(b => {
  b.addEventListener("click", () => {
    const lang = b.dataset.lang;
    if (lang === "fr") { // retour au français : on efface le cookie de traduction
      document.cookie = "googtrans=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
      location.reload();
      return;
    }
    const liste = document.querySelector(".goog-te-combo"); // liste cachée de Google
    if (!liste) return; // Google n'est pas encore chargé
    liste.value = lang;
    liste.dispatchEvent(new Event("change"));
    langueActuelle.textContent = NOMS_LANGUES[lang];
  });
});
/* ===== AJOUT : INCLINAISON 3D ET REFLET 
SUR LES RÉALISATIONS ===== */
/* À coller tout à la FIN de js/script.js. 
N'affecte pas le clic ni la fenêtre de 
description. */
/* Le ";" ci-dessous est volontaire : il 
évite une erreur si la ligne précédente 
n'en a pas */
;(function () {
  const souris = window.matchMedia("(hover: hover)").matches;      // vrai sur ordinateur
  const calme = window.matchMedia("(prefers-reduced-motion: reduce)").matches; // vrai si animations désactivées
  document.querySelectorAll(".galerie figure").forEach(fig => {
    const reflet = document.createElement("span"); // petit calque lumineux ajouté automatiquement
    reflet.className = "reflet";
    fig.appendChild(reflet);
    if (souris && !calme) {
      fig.addEventListener("mousemove", e => {
        const r = fig.getBoundingClientRect();
        const x = (e.clientX - r.left) / r.width;   // position de la souris : 0 (gauche) à 1 (droite)
        const y = (e.clientY - r.top) / r.height;   // 0 (haut) à 1 (bas)
        const force = 14;                           // MODIFIER : angle d'inclinaison maximal (en degrés)
        fig.style.transform = "perspective(700px) rotateY(" + ((x - 0.5) * force) + "deg) rotateX(" + ((0.5 - y) * force) + "deg) scale(1.03)";
        fig.style.setProperty("--x", (x * 100) + "%");
        fig.style.setProperty("--y", (y * 100) + "%");
      });
      fig.addEventListener("mouseleave", () => { fig.style.transform = ""; });
    }
  });
})();
