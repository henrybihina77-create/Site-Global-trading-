/* =========================================================
   GLOBAL TRADING - SCRIPT
   4 petites fonctions, chacune dans sa partie.
   ========================================================= */

/* ===== 1. MENU TÉLÉPHONE : ouvrir / fermer ===== */
const bouton = document.getElementById("menuBouton");
const menu = document.getElementById("menu");
bouton.addEventListener("click", () => menu.classList.toggle("ouvert"));
// Referme le menu quand on clique sur un lien
menu.querySelectorAll("a").forEach(lien =>
  lien.addEventListener("click", () => menu.classList.remove("ouvert")));

/* ===== 2. OMBRE SOUS L'EN-TÊTE quand on descend dans la page ===== */
const entete = document.getElementById("entete");
window.addEventListener("scroll", () =>
  entete.classList.toggle("ombre", window.scrollY > 10));

/* ===== 3. APPARITION DES ÉLÉMENTS ET COMPTEURS ===== */
// Les éléments .apparait deviennent visibles quand ils entrent à l'écran
const observateur = new IntersectionObserver(entrees => {
  entrees.forEach(e => {
    if (e.isIntersecting) { e.target.classList.add("visible"); observateur.unobserve(e.target); }
  });
}, { threshold: 0.15 }); // 0.15 = visible à 15 % avant de s'animer
document.querySelectorAll(".apparait").forEach(el => observateur.observe(el));

// Compteurs des chiffres clés : compte de 0 jusqu'à data-cible (voir index.html, partie 4)
document.querySelectorAll("[data-cible]").forEach(el => {
  const cible = Number(el.dataset.cible);
  const pas = Math.max(1, Math.round(cible / 60)); // vitesse de comptage
  let n = 0;
  const minuteur = setInterval(() => {
    n = Math.min(n + pas, cible);
    el.textContent = n;
    if (n >= cible) clearInterval(minuteur);
  }, 25);
});

/* ===== 4. FORMULAIRE : ouvre la messagerie du visiteur ===== */
// MODIFIER : remplacez par l'adresse e-mail réelle de l'entreprise
const EMAIL_ENTREPRISE = "contact@global-trading.net";

document.getElementById("formulaire").addEventListener("submit", e => {
  e.preventDefault(); // empêche le rechargement de la page
  const nom = document.getElementById("nom").value;
  const tel = document.getElementById("tel").value;
  const msg = document.getElementById("message").value;
  const sujet = encodeURIComponent("Demande de devis - " + nom);
  const corps = encodeURIComponent(msg + "\n\nNom : " + nom + "\nTéléphone : " + tel);
  window.location.href = "mailto:" + EMAIL_ENTREPRISE + "?subject=" + sujet + "&body=" + corps;
});

/* ===== 5. ANNÉE AUTOMATIQUE dans le pied de page ===== */
document.getElementById("annee").textContent = new Date().getFullYear();
